module.exports = { 
  mysqlHost: "localhost",
    user: "",
    password: '',
    database: "silky_exchange",
    mysqlPort: 3306,
    JWT_SECRET_KEY: '',
    SESSION_EXPIRES_IN: '24h',
    imageUrl:'',
    contractAddress : '0xFe976ce253d10F7D34817236f040C8e4Daa4440B',
    mailUrl : 'https://silkyex.io/',
    // mailUrl : 'http://localhost:3000/silky_exchange/',
}